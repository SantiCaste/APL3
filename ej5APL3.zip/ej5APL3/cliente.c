#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <signal.h>

#define TAM_LINEA 100

int validarLinea(char* cad);

void manejador(int sig);

void mostrarError();

int main(int argc, char* argv[]){

    if(argc != 3)
    {
        puts("Deben ingresarse IP del servidor y el puerto de escucha.");
        return 1;
    }

    char linea[TAM_LINEA];
    int sock;
    struct sockaddr_in sa;

    if((sock=socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        printf("No se pudo crear el socket.\n");
        return 1;
    }

    bzero((char*) &sa, sizeof(struct sockaddr_in));
    sa.sin_family       = AF_INET;
    sa.sin_port         = htons(atoi(argv[2]));
    sa.sin_addr.s_addr  = inet_addr(argv[1]);

    //solicitud de conexión:

    if(connect(sock, (struct sockaddr *) &sa, sizeof(sa)) == -1)
    {
        printf("Solicitud rechazada.\n");
        return 1;
    }

    signal(SIGUSR1, manejador);
    recv(sock, linea, TAM_LINEA, 0);

    if(strcmp(linea, "TODO OK") != 0 && strcmp(linea, "LISTO") != 0)
    {
        puts(linea);
        return 1;
    }

    char pidCliente[TAM_LINEA];
    sprintf(pidCliente, "%d", getpid());

    send(sock, pidCliente, TAM_LINEA, 0);

    printf("\nIngrese la consulta: ");

    int flag = 0;

    do{
        fgets(linea, TAM_LINEA, stdin);
        char* act = strchr(linea, '\n');
        if(act)
            *act = '\0';

        flag = validarLinea(linea);
        if(!flag)
            printf("\nIngrese la consulta: ");
    }while(flag == 0);

    send(sock, linea, TAM_LINEA, 0);

    if(strcmp("CONSULTA", linea) == 0)
    {
        printf("GATOS DADOS DE ALTA:\n");
        //tendria que ir mostrando todo el archivo:

        recv(sock, linea, TAM_LINEA, 0);
        while(strcmp(linea, "LISTO") != 0)
        {
            printf("%s", linea);
            recv(sock, linea, TAM_LINEA, 0);
        }
    }


//si hubo cambios en el area compartida es porque hay un error que informar (o fue una consulta).
    char error[TAM_LINEA];

    recv(sock, error, TAM_LINEA, 0);


    if(strcmp(error, "SIN ERROR") != 0)
    {
        printf("%s", error);
    }


    close(sock);
    return 0;
}

int validarLinea(char* cad)
{
    if(!strstr(cad, "CONSULTA") && !strstr(cad, "ALTA") && !strstr(cad, "BAJA")){
        printf("\nLa solicitud debe contener la palabra ALTA, BAJA O CONSULTA\n");
        return 0;
    }

    char comando[10];

    sscanf(cad, "%s", comando);

    if(strcmp(comando, "CONSULTA") != 0 && strcmp(comando, "ALTA") != 0 && strcmp(comando, "BAJA") != 0)
    {
        printf("\nLa solicitud debe comenzar con la palabra ALTA, BAJA O CONSULTA.");
        return 0;
    }

    if(strcmp(cad, "CONSULTA") == 0) //ta bien
    {
        return 1;
    }

    char* act = strchr(cad, ' ');
    if(!act)
    {
        printf("\nERROR. La solicitud ingresada no es válida.\n");
        return 0;
    }

    if(strcmp(comando, "CONSULTA") == 0)
    {
        if(strchr(act + 1, ' ')) //si tiene mas espacios despues de poner un nombre es invalida.
        {
            printf("\nERROR. La solicitud ingresada no es válida.\n");
            return 0;
        }
        else
            return 1;
    }

    if(strcmp(comando, "BAJA") == 0)
    {
        if(strchr(act + 1, ' '))
        {
            printf("\nERROR. La solicitud ingresada no es válida.\n");
            return 0;
        }
        else
            return 1;
    }

    if(strcmp(comando, "ALTA") == 0)
    {

        char sexo[10];
        char castrado[10];

        char aux[TAM_LINEA];
        strcpy(aux, cad);

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        strcpy(castrado, act + 1);

        *act = '\0';

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        strcpy(sexo, act + 1);

        *act = '\0';

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        *act = '\0'; //no me interesa que raza haya puesto.

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        *act = '\0'; //no me interesa el nombre que haya puesto.

        act = strchr(aux, ' ');

        if(act) //si sigue encontrando espacios a esta altura es porque se escribió algo invalido.
        {
            mostrarError();
            return 0;
        }

        int flag = 1;
        if(strcmp(sexo, "M") != 0 && strcmp(sexo, "H") != 0)
        {
            printf("\nERROR: Cuando se da de alta el tercer campo (sexo) debe ser M/H.\n");
            flag = 0;
        }

        if(strcmp(castrado, "CA") != 0 && strcmp(castrado, "SC") != 0)
        {
            printf("\nERROR: Cuando se da de alta el ultimo campo (si fue castrado o no) debe ser CA/SC.\n");
            flag = 0;
        }

        //si llega hasta acá no tuvo errores.
        return flag;
    }

//si llega hasta acá algo salió mal.
    return 0;
}

void mostrarError()
{
    printf("\nERROR. La solicitud ingresada no es válida.\n");
    printf("La solicitud debe ser de la forma:\nCOMANDO Nombre Raza Sexo(M/H) Condición (CA/SC).\n");

}

void manejador(int sig)
{
    puts("\n\nEL PROCESO SERVIDOR HA FINALIZADO\n\nSE TERMINARÁ AL PROCESO CLIENTE TAMBIÉN\n");
    kill(getpid(), SIGINT);
}
