#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>

#include <semaphore.h>
#include <signal.h>

#include <pthread.h>

#define TAM_LINEA 100
#define TRUE 1
#define FALSE 0
#define TAM_NOMBRE 20

#define MAX_QUEUE 3 //cuantas peticiones maximas pueden hacerse al servidor.
//supongo que debe ser 3.

/*
#-----------------------Inicio Encabezado------------------------------##
# Nombre Script: "servidor.c"
# Numero Trabajo Practico: 3
# Numero Ejercicio: 5
# Tipo: 1° Entrega
# Integrantes:
#
#       Nombre y Apellido                                  DNI
#       ---------------------                           ----------
#       Santiago Castellani                             43.316.372
#       Federico Pucci                                  41.106.855
#       Martina Gloria Turello                          43.719.495
#       Federico Gabriel Castro                         43.818.997
#       Valentín Alejandro López                        43.918.206
##-----------------------Fin del Encabezado-----------------------------##
*/

typedef struct{
    char nombre[TAM_NOMBRE];
    char raza[15];
    char sexo;
    int castrado; //0 = sin castrar, 1 = castrado.
}
Paciente;

int pidCliente[3];

typedef struct{
    int client_socket;
    int numero;
}argHilo;

void manejador(int sig); //el handler de SIGUSR1

int compararNombre(const void* e1, const void* e2);
int procesarLinea(char* cad, Paciente* paciente, char* tipo);
int buscarNombre(FILE* archivo, const char* nombre);
void mostrarArchivo(FILE* archivo, int cliente_socket);
void buscarPaciente(FILE* archivo, const char* nombre, char* lineaBuscado);
void borrarNombre(FILE* nombres, FILE* archivo, char* nombre, const char* nombreArch1,
const char* nombreArch2);
void mostrarAyuda();

int fin = FALSE;
int server_socket;

void* mainHilo(void* arg)
{
    argHilo* argum = (argHilo*) arg;

    sem_t* hiloActivo;
    if(argum->numero == 0)
        hiloActivo = sem_open("/hilo0Fin", O_CREAT);
    else
    if(argum->numero == 1)
        hiloActivo = sem_open("/hilo1Fin", O_CREAT);
    else
        hiloActivo = sem_open("/hilo2Fin", O_CREAT);

    FILE *arch, *nombres;
    char tipoComando[10];
    char linea[TAM_LINEA];
    char error[TAM_LINEA];
    strcpy(error, "SIN ERROR");
    int resu;
    Paciente paciente;
    strcpy(paciente.nombre, " ");


    int client_socket = argum->client_socket;

    bzero(linea, TAM_LINEA);

    char lineaPid[TAM_LINEA];

    recv(client_socket, lineaPid, TAM_LINEA, 0); //primero recibe el pid del cliente.

    sscanf(lineaPid, "%d", &pidCliente[argum->numero]);

    recv(client_socket, linea, TAM_LINEA, 0);

    arch = fopen("gatitos", "a+");
    nombres = fopen(".nombres", "a+");

    resu = procesarLinea(linea, &paciente, tipoComando);

    if(strcmp(tipoComando, "ALTA") == 0)
    {
        if(buscarNombre(nombres, paciente.nombre) == 0)
        {
            fprintf(nombres, "%s\n", paciente.nombre);
            fprintf(arch, "%s %s %c %s\n", paciente.nombre, paciente.raza, paciente.sexo, paciente.castrado == 1 ? "CA" : "SC");
        }
        else
        {
            strcpy(error, "ERROR\n");
            strcat(error, paciente.nombre);
            strcat(error, " ya se encuentra dado de alta.\n");
            send(client_socket, error, TAM_LINEA, 0);
        }
    }

    if(strcmp(tipoComando, "CONSULTA") == 0)
    {
        if(paciente.nombre && strcmp(paciente.nombre, " ") != 0)
        {
            if(buscarNombre(nombres, paciente.nombre) == 1)
            {
                char buscado[TAM_LINEA];
                buscarPaciente(arch, paciente.nombre, buscado);
                strcpy(error, "Los datos del gato buscado son:\n");
                strcat(error, buscado);
                strcat(error, "\n");
                send(client_socket, error, TAM_LINEA, 0);
            }
            else
            {
                strcpy(error, "ERROR\nNo existen gatos con el nombre ");
                strcat(error, paciente.nombre);
                strcat(error, "\n");
                send(client_socket, error, TAM_LINEA, 0);
            }
        }
        else
        {
            mostrarArchivo(arch, client_socket);
            //condicion de corte del lado del cliente:
            send(client_socket, "LISTO", TAM_LINEA, 0);
        }
    }

    if(strcmp(tipoComando, "BAJA") == 0)
    {
        if(buscarNombre(nombres, paciente.nombre) == 1)
            borrarNombre(nombres, arch, paciente.nombre, ".nombres", "gatitos");
        else
        {
            strcpy(error, "ERROR\nNo existen gatos con el nombre ");
            strcat(error, paciente.nombre);
            strcat(error, "\n");
            send(client_socket, error, TAM_LINEA, 0);
        }
    }

    if(strcmp(error, "SIN ERROR") == 0)
    {
        //puts("Entra en el if de SIN ERROR");
        send(client_socket, error, TAM_LINEA, 0); //TAM_LINEA o strlen(error)?
    }

    strcpy(paciente.nombre, " ");
    strcpy(error, "SIN ERROR");

    //porque en borrarNombres ya los cierra.
    if(strcmp(tipoComando, "BAJA") != 0)
    {
        fclose(arch);
        fclose(nombres);
    }

    //lo pongo aca para que el main se de cuenta de que finalizo un hilo.
    sem_post(hiloActivo);

    sem_close(hiloActivo);

    pthread_exit(0);
}


//con esta version implemento hilos.
int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        puts("Error al ejecutar el script.");
        puts("Se debe ingresar un unico parametro.");
        return 1;
    }

    if(strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0)
    {
        mostrarAyuda();
        return 1;
    }

    signal(SIGINT, SIG_IGN);

    //vector de hilos:

    pthread_t hilos[3];

    int hilosHabilitados[3] = {0, 0 ,0};

    int cantHilos = 0;

    //empiezo:
    sem_t* singleton = sem_open("/singleton", O_CREAT, 0666, 1);

    int rc = sem_trywait(singleton); //deberia hacer esto antes de los unlink.
    if(rc != 0)
    {
        puts("No se puede crear otro proceso debido a que ya existe uno.");
        return 1;
    }

    sem_t* hilo0Fin = sem_open("/hilo0Fin", O_CREAT | O_EXCL, 0666, 0);
    sem_t* hilo1Fin = sem_open("/hilo1Fin", O_CREAT | O_EXCL, 0666, 0);
    sem_t* hilo2Fin = sem_open("/hilo2Fin", O_CREAT | O_EXCL, 0666, 0);

    socklen_t cl=sizeof(struct sockaddr_in);
    struct sockaddr_in sa;
    struct sockaddr_in ca;
    int client_socket;
    int habilitar = 1;
    //char linea[TAM_LINEA];
    char error[TAM_LINEA]; //los mensajes que se le mandan al cliente.
    strcpy(error, "SIN ERROR");

    if((server_socket=socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        printf("No se pudo crear el socket.\n");
        return 1;
    }

    if(setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &habilitar, sizeof(int)) < 0)
    {
        printf("No se pudo configurar opciones del socket.\n");
        return 1;
    }

    //configuración del servidor:
    bzero((char*) &sa, sizeof(struct sockaddr_in));
    sa.sin_family       = AF_INET;
    sa.sin_port         = htons(atoi(argv[1]));
    sa.sin_addr.s_addr  = INADDR_ANY;

    bind(server_socket, (struct sockaddr*)&sa, sizeof(struct sockaddr_in));


    listen(server_socket, MAX_QUEUE);

    //EMPIEZA EL DEMONIO:

    signal(SIGUSR1, manejador);


    pid_t pid = fork();
    if(pid < 0)
    {
        printf("ERROR AL EJECUTAR EL SCRIPT.\n");
        return 1;
    }
    if(pid > 0)
    {
        return 0; //finaliza el proceso padre.
    }
    pid_t sid = setsid();
    if(sid < 0)
    {
        printf("ERROR AL EJECUTAR EL SCRIPT.\n");
        return 1;
    }

    argHilo arg;
    //loop principal:

    while(!fin)
    {
        //puts("espera accept");
        client_socket = accept(server_socket, (struct sockaddr *) &ca, &cl);
        //puts("sale de accept");
        arg.client_socket = client_socket;

        if(sem_trywait(hilo0Fin) == 0)
        {
            pthread_join(hilos[0], NULL); //asi?
            //puts("puede hacer el join de hilo 0");
            hilosHabilitados[0] = 0;
            cantHilos--;
        }

        if(sem_trywait(hilo1Fin) == 0)
        {
            pthread_join(hilos[1], NULL); //asi?
            //puts("puede hacer el join de hilo 1");
            hilosHabilitados[1] = 0;
            cantHilos--;
        }

        if(sem_trywait(hilo2Fin) == 0)
        {
            pthread_join(hilos[2], NULL); //asi?
            //puts("puede hacer el join de hilo 2");
            hilosHabilitados[2] = 0;
            cantHilos--;
        }

        if(!fin) //para que en el ultimo ciclo (cuando se manda la SIGUSR1) no haga todo esto.
        {
            if(cantHilos < 3)
            {
                //Mandarle algo para que no se quede esperando con el recv.
                send(client_socket, "TODO OK", TAM_LINEA, 0);

                //arg.numero = cantHilos; //su identificador.

                int num;

                //para saber que hilo habilitar, sino hay problemas con la superposición de clientes.
                if(hilosHabilitados[0] == 0)
                {
                    num = 0;
                    hilosHabilitados[0] = 1;
                    arg.numero = 0;
                }
                else if(hilosHabilitados[1] == 0)
                {
                    num = 1;
                    hilosHabilitados[1] = 1;
                    arg.numero = 1;
                }
                else if(hilosHabilitados[2] == 0)
                {
                    num = 2;
                    hilosHabilitados[2] = 1;
                    arg.numero = 2;
                }

                pthread_create(&hilos[num], NULL, &mainHilo, (void*)(&arg));
                cantHilos++;
            }
            else
            {
                strcpy(error, "ERROR\nYa existen 3 clientes en este momento.\n");
                send(client_socket, error, TAM_LINEA, 0);
            }
        }
    }

    //desvinculo la MC:

    sem_post(singleton); //PARA QUE LO PUEDA USAR OTRA INSTANCIA.

    sem_close(singleton);

        if(sem_trywait(hilo0Fin) == 0)
        {
            pthread_join(hilos[0], NULL); //asi?
            //puts("puede hacer el join de hilo 0");
            hilosHabilitados[0] = 0;
            cantHilos--;
        }

        if(sem_trywait(hilo1Fin) == 0)
        {
            pthread_join(hilos[1], NULL); //asi?
            //puts("puede hacer el join de hilo 1");
            hilosHabilitados[1] = 0;
            cantHilos--;
        }

        if(sem_trywait(hilo2Fin) == 0)
        {
            pthread_join(hilos[2], NULL); //asi?
            //puts("puede hacer el join de hilo 2");
            hilosHabilitados[2] = 0;
            cantHilos--;
        }

    sem_close(hilo0Fin);
    sem_close(hilo1Fin);
    sem_close(hilo2Fin);

    sem_unlink("/hilo0Fin");
    sem_unlink("/hilo1Fin");
    sem_unlink("/hilo2Fin");

    sem_unlink("/singleton");

    close(server_socket);
    close(client_socket);



    return 0;
}

int procesarLinea(char* cad, Paciente* paciente, char* tipo)
{
    char lineaAux[TAM_LINEA];
    strcpy(lineaAux, cad); //por si necesito recuperarla.
    int resu = 1;

    char* act = strrchr(cad, ' ');
    //si no encuentra este espacio es porque solo tiene CONSULTA.
    if(act) //si encuentra el espacio entonces no es "CONSULTA sin nombre."
    {
        paciente->castrado = (strcmp(act, "CA") == 0) ? 1 : 0;
        *act = '\0';
        act = strrchr(cad, ' ');
        //si no encuentra este espacio es porque llegó a leer solo hasta el nombre (CONSULTA O BAJA).
        if(act) //si encuentra el espacio no es BAJA nombre o CONSULTA Nombre.
        {

            sscanf(act + 1, "%c", &paciente->sexo);
            *act = '\0';

            act = strrchr(cad, ' ');
            strcpy(paciente->raza, act + 1);
            *act = '\0';

            act = strrchr(cad, ' ');
            strcpy(paciente->nombre, act + 1);
            *act = '\0';

            strcpy(tipo, cad);
        }
        else //es CONSULTA Nombre o BAJA nombre.
        {
            act = strrchr(lineaAux, ' ');
            strcpy(paciente->nombre, act + 1);
            *act = '\0';

            strcpy(tipo, lineaAux);
        }
    }
    else //es CONSULTA sin nombre.
    {
        strcpy(tipo, lineaAux);
    }

    return resu;
}

int buscarNombre(FILE* archivo, const char* nombre)
{
    int flag = 0;
    char actual[TAM_NOMBRE];
    fgets(actual, TAM_NOMBRE, archivo);

    while(flag == 0 && !feof(archivo))
    {
        char* act = strchr(actual, '\n');
        if(act)
            *act = '\0';

        if(strcmp(actual, nombre) == 0)
        {
            flag = 1;
        }

        fgets(actual, TAM_NOMBRE, archivo);
    }

    return flag;
}

void buscarPaciente(FILE* archivo, const char* nombre, char* lineaBuscado)
{
    int flag = 0;
    char aux[TAM_LINEA]; //una copia de la cadena actual.

    fgets(lineaBuscado, TAM_LINEA, archivo);
    while(flag == 0 && !feof(archivo))
    {
        char* act = strchr(lineaBuscado, '\n');
        if(act)
            *act = '\0';

        strcpy(aux, lineaBuscado);
        act = strchr(aux, ' ');
        *act = '\0';

        if(strcmp(aux, nombre) == 0)
        {
            flag = 1;
        }
        else
            fgets(lineaBuscado, TAM_LINEA, archivo);
    }
}

void mostrarArchivo(FILE* archivo, int cliente_socket)
{
    char linea[TAM_LINEA];

    fgets(linea, TAM_LINEA, archivo);
    while(!feof(archivo))
    {
//        printf("Mando %s\n", linea);
        send(cliente_socket, linea, TAM_LINEA, 0);
        fgets(linea, TAM_LINEA, archivo);
        //capaz se necesita sincronizacion para poder mostrar todo.
    }
}

void borrarNombre(FILE* nombres, FILE* archivo, char* nombre, const char* nombreArch1,
const char* nombreArch2)
{
    int flag1, flag2;
    flag1 = flag2 = 0;

    FILE* auxNombres = fopen("auxNombres", "wt");
    FILE* auxArchivo = fopen("auxArchivo", "wt");

    //no se si va.
    fseek(nombres, 0, SEEK_SET);
    fseek(archivo, 0, SEEK_SET);

    char nombreActual[TAM_NOMBRE];



    fgets(nombreActual, TAM_NOMBRE, nombres);
    while(!feof(nombres))
    {
        char* act = strchr(nombreActual, '\n');
        *act = '\0';


        if(strcmp(nombreActual, nombre) != 0)
        {

            fprintf(auxNombres, "%s\n", nombreActual);
        }

        fgets(nombreActual, TAM_NOMBRE, nombres);
    }


    fclose(nombres);

    fclose(auxNombres);


    remove(nombreArch1);

    rename("auxNombres", nombreArch1);

    char lineaActual[TAM_LINEA];

    fgets(lineaActual, TAM_LINEA, archivo);
    while(!feof(archivo))
    {
        char* act = strchr(lineaActual, '\n');
        *act = '\0';
        if(!strstr(lineaActual, nombre))
        {
            fprintf(auxArchivo, "%s\n", lineaActual);
        }

        fgets(lineaActual, TAM_LINEA, archivo);
    }


    fclose(archivo);
    fclose(auxArchivo);
    remove(nombreArch2);
    rename("auxArchivo", nombreArch2);
}

void mostrarAyuda()
{
    puts("Este programa permite manejar un sistema cliente-servidor de un refugio de gatos.");
    puts("Para ejecutar el proceso primero debe llamarse a ejecutar el programa servidor ingresando ./servidor y un numero de puerto (Ej: 5000)");
    puts("Luego debe llamarse al programa ./cliente con parámetros IP (127.0.0.1) y puerto (el mismo que el usado en ./servidor)");
    puts("Luego de ser recibidor por el servidor se debe ingresar una de las siguientes opciones:");
    puts("ALTA nombre raza sexo castrado (ej: ALTA Claudio Siames M/H CA/SC) --> da de alta a un gato con esas caracteristica.");
    puts("BAJA nombre (ej: BAJA Claudio) --> da de baja al gato cuyo nombre se encuentra en los registros.");
    puts("CONSULTA nombre (ej: CONSULTA Cluadio) --> Consulta los datos del gato cuyo nombre es el ingresado.");
    puts("CONSULTA --> Consulta los datos de todos los gatos registrados.");
    puts("\nEste programa admite hasta 3 clientes en simultaneo.");
    puts("\nEL ORDEN DE EJECUCIÓN DE LOS PROCESOS DEBE SER PRIMERO ./servidor Y LUEGO ./cliente.");
}

void manejador(int sig)
{
    //printf("SE FINALIZÓ EL DEMONIO MEDIANTE UNA SEÑAL.\n");
    fin = TRUE;

    for(int i = 0; i < 3; i++)
    {
        if(pidCliente[i] > 0)
            kill(pidCliente[i], 10);
    }
    //sem_post(hayCliente); //idem arriba.

    close(server_socket);
}

/* FIN DE ARCHIVO */
