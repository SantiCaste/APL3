#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

/*
#-----------------------Inicio Encabezado------------------------------##
# Nombre Script: "servidor.c"
# Numero Trabajo Practico: 3
# Numero Ejercicio: 4
# Tipo: 1° Entrega
# Integrantes:
#
#       Nombre y Apellido                                  DNI
#       ---------------------                           ----------
#       Santiago Castellani                             43.316.372
#       Federico Pucci                                  41.106.855
#       Martina Gloria Turello                          43.719.495
#       Federico Gabriel Castro                         43.818.997
#       Valentín Alejandro López                        43.918.206
##-----------------------Fin del Encabezado-----------------------------##
*/


#define SEGMENTO_ID 234
#define TAM_LINEA 100
#define TRUE 1
#define FALSE 0
#define TAM_NOMBRE 20
typedef struct{
    char nombre[TAM_NOMBRE];
    char raza[15];
    char sexo;
    int castrado; //0 = sin castrar, 1 = castrado.
}
Paciente;

void manejador(int sig); //el handler de SIGUSR1

int compararNombre(const void* e1, const void* e2);
int procesarLinea(char* cad, Paciente* paciente, char* tipo);
int buscarNombre(FILE* archivo, const char* nombre);
void mostrarArchivo(FILE* archivo, char* compartida, sem_t* semaforo, sem_t* permiso);
void buscarPaciente(FILE* archivo, const char* nombre, char* lineaBuscado);
void borrarNombre(FILE* nombres, FILE* archivo, char* nombre, const char* nombreArch1,
const char* nombreArch2);
void mostrarAyuda();

int fin = FALSE;
sem_t* lee;
sem_t* hayCliente;
int pidCliente;

int main(int argc, char* argv[])
{
    if(argc == 2)
    {
        if(strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0)
        {
            mostrarAyuda();
        }
        else
            puts("Error al ejecutar el script (los parametros ingresados fueron invalidos).");
    }
    else if(argc == 1)
    {
        signal(SIGINT, SIG_IGN);

        //empiezo:
        lee = sem_open("/lee", O_CREAT | O_EXCL, 0666, 0); //el servidor lee del cliente.
        sem_t* escribi = sem_open("/escribi", O_CREAT | O_EXCL, 0666, 0);
        hayCliente = sem_open("/hayCliente", O_CREAT | O_EXCL, 0666, 0);

        sem_t* error = sem_open("/error", O_CREAT | O_EXCL, 0666, 0);
        sem_t* muestraGato = sem_open("/muestraGato", O_CREAT | O_EXCL, 0666, 0);
        sem_t* permisoMuestra = sem_open("/permisoMuestra", O_CREAT | O_EXCL, 0666, 0);
        sem_t* singleton = sem_open("/singleton", O_CREAT, 0666, 1);

        int rc = sem_trywait(singleton); //deberia hacer esto antes de los unlink.
        if(rc == 0)
        {
            FILE *arch, *nombres;

            //creo la memoria compartida:
            int shmid = shmget(SEGMENTO_ID, TAM_LINEA, IPC_CREAT | 0666);
            printf("\nShmid: %d\n", shmid);

            //vinculo la memoria compartida:
            char* area_compartida = (char*)shmat(shmid, NULL, 0);

            char tipoComando[10];
            Paciente paciente;

            strcpy(paciente.nombre, " ");
            int resu;

            //EMPIEZA EL DEMONIO:

            signal(SIGUSR1, manejador);
            pid_t pid = fork();
            if(pid < 0)
            {
                printf("ERROR AL EJECUTAR EL SCRIPT.\n");
                return 1;
            }
            if(pid > 0)
            {
                return 0; //finaliza el proceso padre.
            }
            pid_t sid = setsid();
            if(sid < 0)
            {
                printf("ERROR AL EJECUTAR EL SCRIPT.\n");
                return 1;
            }

            while(!fin)
            {

                sem_wait(hayCliente); //espera a que haya un cliente.

                sscanf(area_compartida, "%d", &pidCliente);

                sem_post(escribi);

                sem_wait(lee); //espero a que el cliente haya escrito algo.

                if(!fin) //para que en el ultimo ciclo (cuando se manda la SIGUSR1) no haga todo esto.
                {
                    arch = fopen("gatitos", "a+");
                    nombres = fopen(".nombres", "a+");

                    char linea[TAM_LINEA];
                    strcpy(linea, area_compartida);

                    resu = procesarLinea(linea, &paciente, tipoComando);

                    if(strcmp(tipoComando, "ALTA") == 0)
                    {
                        if(buscarNombre(nombres, paciente.nombre) == 0)
                        {
                            fprintf(nombres, "%s\n", paciente.nombre);
                            fprintf(arch, "%s %s %c %s\n", paciente.nombre, paciente.raza, paciente.sexo, (paciente.castrado == 1) ? "CA" : "SC");
                        }
                        else
                        {
                            strcpy(area_compartida, "ERROR\n");
                            strcat(area_compartida, paciente.nombre);
                            strcat(area_compartida, " ya se encuentra registrado.");
                        }
                    }
                    if(strcmp(tipoComando, "CONSULTA") == 0)
                    {
                        if(paciente.nombre && strcmp(paciente.nombre, " ") != 0)
                        {
                            if(buscarNombre(nombres, paciente.nombre) == 1)
                            {
                                char buscado[TAM_LINEA];
                                buscarPaciente(arch, paciente.nombre, buscado);
                                strcpy(area_compartida, "Los datos del gato consultado son:\n");
                                strcat(area_compartida, buscado);
                            }
                            else
                            {
                                strcpy(area_compartida, "ERROR\nNo existen gatos registrados con el nombre ");
                                strcat(area_compartida, paciente.nombre);
                            }
                        }
                        else
                        {
                            char aux[TAM_LINEA];
                            strcpy(aux, area_compartida);
                            mostrarArchivo(arch, area_compartida, muestraGato, permisoMuestra);
                            //condición de corte para el while de cliente:
                            strcpy(area_compartida, "LISTO");
                            sem_post(muestraGato);
                        }
                    }

                    if(strcmp(tipoComando, "BAJA") == 0)
                    {


                        if(buscarNombre(nombres, paciente.nombre) == 1)
                            borrarNombre(nombres, arch, paciente.nombre, ".nombres", "gatitos");
                        else
                        {
                            strcpy(area_compartida, "ERROR\nNo existen gatos registrados con el nombre ");
                            strcat(area_compartida, paciente.nombre);
                        }

                    }

                strcpy(paciente.nombre, " ");

                //es para resetear el nombre y que me funcione en la siguiente iteración el caso en que
                //no se ponga un nombre.

                    if(strcmp(tipoComando, "BAJA") != 0)
                    {
                        fclose(arch);
                        fclose(nombres);
                    }

//                    sem_post(escribi); ahora va arriba pq lo levanto cuando recibo el pid.
                    sem_post(error);
                }
            }

            //desvinculo la MC:
            shmdt(&area_compartida);

            shmctl(shmid, IPC_RMID, NULL);

            sem_close(lee);
            sem_close(escribi);
            sem_close(error);
            sem_close(muestraGato);
            sem_close(permisoMuestra);

            sem_close(hayCliente);

            sem_post(singleton); //PARA QUE LO PUEDA USAR OTRA INSTANCIA.

            sem_close(singleton);

            sem_unlink("/lee");
            sem_unlink("/escribi");
            sem_unlink("/error");
            sem_unlink("/muestraGato");
            sem_unlink("/permisoMuestra");
            sem_unlink("/singleton");

            sem_unlink("/hayCliente");


        }
        else
            puts("No se puede crear otro proceso debido a que ya existe uno.");

        return 0;
    }
    else
        puts("Error al ejecutar el script.");
}

int procesarLinea(char* cad, Paciente* paciente, char* tipo)
{
    char lineaAux[TAM_LINEA];
    strcpy(lineaAux, cad); //por si necesito recuperarla.
    int resu = 1;

    char* act = strrchr(cad, ' ');
    //si no encuentra este espacio es porque solo tiene CONSULTA.
    if(act) //si encuentra el espacio entonces no es "CONSULTA sin nombre."
    {
        paciente->castrado = (strcmp(act + 1, "CA") == 0) ? 1 : 0;
        *act = '\0';
        act = strrchr(cad, ' ');
        //si no encuentra este espacio es porque llegó a leer solo hasta el nombre (CONSULTA O BAJA).
        if(act) //si encuentra el espacio no es BAJA nombre o CONSULTA Nombre.
        {

            sscanf(act + 1, "%c", &paciente->sexo);
            *act = '\0';

            act = strrchr(cad, ' ');
            strcpy(paciente->raza, act + 1);
            *act = '\0';

            act = strrchr(cad, ' ');
            strcpy(paciente->nombre, act + 1);
            *act = '\0';

            strcpy(tipo, cad);
        }
        else //es CONSULTA Nombre o BAJA nombre.
        {
            act = strrchr(lineaAux, ' ');
            strcpy(paciente->nombre, act + 1);
            *act = '\0';

            strcpy(tipo, lineaAux);
        }
    }
    else //es CONSULTA sin nombre.
    {
        strcpy(tipo, lineaAux);
    }

    return resu;
}

int buscarNombre(FILE* archivo, const char* nombre)
{
    int flag = 0;
    char actual[TAM_NOMBRE];
    fgets(actual, TAM_NOMBRE, archivo);

    while(flag == 0 && !feof(archivo))
    {
        char* act = strchr(actual, '\n');
        if(act)
            *act = '\0';

        if(strcmp(actual, nombre) == 0)
        {
            flag = 1;
        }

        fgets(actual, TAM_NOMBRE, archivo);
    }

    return flag;
}

void buscarPaciente(FILE* archivo, const char* nombre, char* lineaBuscado)
{
    int flag = 0;
    char aux[TAM_LINEA]; //una copia de la cadena actual.

    fgets(lineaBuscado, TAM_LINEA, archivo);
    while(flag == 0 && !feof(archivo))
    {
        char* act = strchr(lineaBuscado, '\n');
        if(act)
            *act = '\0';

        strcpy(aux, lineaBuscado);
        act = strchr(aux, ' ');
        *act = '\0';

        if(strcmp(aux, nombre) == 0)
        {
            flag = 1;
        }
        else
            fgets(lineaBuscado, TAM_LINEA, archivo);
    }
}

void mostrarArchivo(FILE* archivo, char* compartida, sem_t* semaforo, sem_t* permiso)
{
    int flag = 0;
    fgets(compartida, TAM_LINEA, archivo);
    while(!feof(archivo))
    {
        flag = 1;
        sem_post(semaforo);

        sem_wait(permiso);
        fgets(compartida, TAM_LINEA, archivo);
    }

    if(flag == 0)
        sem_post(semaforo); //para que no quede bloqueado si no hay datos en el archivo.

}

void borrarNombre(FILE* nombres, FILE* archivo, char* nombre, const char* nombreArch1,
const char* nombreArch2)
{
    int flag1, flag2;
    flag1 = flag2 = 0;

    FILE* auxNombres = fopen("auxNombres", "wt");
    FILE* auxArchivo = fopen("auxArchivo", "wt");

    //no se si va.
    fseek(nombres, 0, SEEK_SET);
    fseek(archivo, 0, SEEK_SET);

    char nombreActual[TAM_NOMBRE];



    fgets(nombreActual, TAM_NOMBRE, nombres);
    while(!feof(nombres))
    {
        char* act = strchr(nombreActual, '\n');
        *act = '\0';


        if(strcmp(nombreActual, nombre) != 0)
        {

            fprintf(auxNombres, "%s\n", nombreActual);
        }

        fgets(nombreActual, TAM_NOMBRE, nombres);
    }


    fclose(nombres);

    fclose(auxNombres);


    remove(nombreArch1);

    rename("auxNombres", nombreArch1);

    char lineaActual[TAM_LINEA];

    fgets(lineaActual, TAM_LINEA, archivo);
    while(!feof(archivo))
    {
        char* act = strchr(lineaActual, '\n');
        *act = '\0';
        if(!strstr(lineaActual, nombre))
        {
            fprintf(auxArchivo, "%s\n", lineaActual);
        }

        fgets(lineaActual, TAM_LINEA, archivo);
    }


    fclose(archivo);
    fclose(auxArchivo);
    remove(nombreArch2);
    rename("auxArchivo", nombreArch2);
}

void mostrarAyuda()
{
    puts("Este script permite manejar un sistema cliente-servidor de un refugio de gatos.");
    puts("Para ejecutar el script primero debe llamarse a ejecutar el script servidor ingresando ./servidor");
    puts("Luego debe llamarse al script ./cliente enviandole una de las siguientes opciones:");
    puts("ALTA nombre raza sexo castrado (ej: ALTA Claudio Siames M/H CA/SC) --> da de alta a un gato con esas caracteristica.");
    puts("BAJA nombre (ej: BAJA Claudio) --> da de baja al gato cuyo nombre se encuentra en los registros.");
    puts("CONSULTA nombre (ej: CONSULTA Cluadio) --> Consulta los datos del gato cuyo nombre es el ingresado.");
    puts("CONSULTA --> Consulta los datos de todos los gatos registrados.");
    puts("\nEL ORDEN DE EJECUCIÓN DE LOS PROCESOS DEBE SER 1° ./servidor Y 2° ./cliente.");

}

void manejador(int sig)
{
    //printf("SE FINALIZÓ EL DEMONIO MEDIANTE UNA SEÑAL.\n");
    fin = TRUE;

    kill(pidCliente, 10);
    sem_post(lee); //lo levanto porque sino se queda tildado el while y no termina nunca.
    sem_post(hayCliente); //idem arriba.
}


/* FIN DE ARCHIVO */
