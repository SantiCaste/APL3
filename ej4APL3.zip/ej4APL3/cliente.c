#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#define SEGMENTO_ID 234
#define TAM_LINEA 100

int validarLinea(char* cad);

void manejador(int sig); //el handler de SIGUSR1

void mostrarError();

//YO INTERPRETÉ QUE UNA VEZ CONECTADO EL CLIENTE PODÍA ESCRIBIR LOS COMANDOS.
int main(){

    sem_t* lee = sem_open("/lee", O_CREAT);
    sem_t* escribi = sem_open("/escribi", O_CREAT);
    sem_t* error = sem_open("/error", O_CREAT);
    sem_t* muestraGato = sem_open("/muestraGato", O_CREAT);
    sem_t* permisoMuestra = sem_open("/permisoMuestra", O_CREAT);

    sem_t* hayCliente = sem_open("/hayCliente", O_CREAT);


    char linea[TAM_LINEA];
    
    int shmid = shmget(SEGMENTO_ID, TAM_LINEA, IPC_CREAT | 0666);

    char* area_compartida = (char*)shmat(shmid, NULL, 0);

//le mando al servidor mi pid asi cuando termina me mata.

    signal(SIGUSR1, manejador);


    sprintf(area_compartida, "%d", getpid());
    sem_post(hayCliente);

    sem_wait(escribi);
    int a;
    printf("\nIngrese la consulta: ");

    int flag = 0;

    do{
        fgets(linea, TAM_LINEA, stdin);
        char* act = strchr(linea, '\n');
        if(act)
            *act = '\0';
            
        flag = validarLinea(linea);

        if(flag == 0)
            printf("\nIngrese la consulta: ");

    }while(flag == 0);

    strcpy(area_compartida, linea);
    sem_post(lee);

    if(strcmp("CONSULTA", linea) == 0)
    {
        printf("GATOS DADOS DE ALTA:\n");
        //tendria que ir mostrando todo el archivo:

        while(strcmp(area_compartida, "LISTO") != 0)
        {
            sem_wait(muestraGato);
            if(strcmp(area_compartida, "LISTO") != 0)
            {
                printf("%s\n", area_compartida);
                sem_post(permisoMuestra);
            }
        }

        strcpy(area_compartida, linea);
    }

    sem_wait(error);
    //si hubo cambios en el area compartida es porque hay un error que informar.

    //lo que viene despues del && es para que no imprima 2 veces la utlima linea del archivo.
    if(strcmp(linea, area_compartida) != 0 && strcmp(linea, "LISTO") != 0)
    {
        printf("%s\n", area_compartida);
    }

    //desvinculo la MC:
    shmdt(&area_compartida);

    sem_close(lee);
    sem_close(escribi);
    sem_close(error);
    sem_close(muestraGato);
    sem_close(permisoMuestra);
    sem_close(hayCliente);

    return 0;
}

int validarLinea(char* cad)
{    
    if(!strstr(cad, "CONSULTA") && !strstr(cad, "ALTA") && !strstr(cad, "BAJA")){
        printf("\nLa solicitud debe contener la palabra ALTA, BAJA O CONSULTA\n");
        return 0;
    }

    char comando[10];

    sscanf(cad, "%s", comando);

    if(strcmp(comando, "CONSULTA") != 0 && strcmp(comando, "ALTA") != 0 && strcmp(comando, "BAJA") != 0)
    {
        printf("\nLa solicitud debe comenzar con la palabra ALTA, BAJA O CONSULTA.");
        return 0;
    }

    if(strcmp(cad, "CONSULTA") == 0) //ta bien
    {
        return 1;
    }

    char* act = strchr(cad, ' ');
    if(!act)
    {
        printf("\nERROR. La solicitud ingresada no es válida.\n");
        return 0;
    }

    if(strcmp(comando, "CONSULTA") == 0)
    {
        if(strchr(act + 1, ' ')) //si tiene mas espacios despues de poner un nombre es invalida.
        {
            printf("\nERROR. La solicitud ingresada no es válida.\n");
            return 0;
        }
        else
            return 1;
    }

    if(strcmp(comando, "BAJA") == 0)
    {
        if(strchr(act + 1, ' '))
        {
            printf("\nERROR. La solicitud ingresada no es válida.\n");
            return 0;
        }
        else
            return 1;
    }

    if(strcmp(comando, "ALTA") == 0)
    {

        char sexo[10];
        char castrado[10];

        char aux[TAM_LINEA];
        strcpy(aux, cad);

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        strcpy(castrado, act + 1);

        *act = '\0';

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        strcpy(sexo, act + 1);

        *act = '\0';

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        *act = '\0'; //no me interesa que raza haya puesto.

        act = strrchr(aux, ' ');
        if(!act)
        {
            mostrarError();
            return 0;
        }

        *act = '\0'; //no me interesa el nombre que haya puesto.

        act = strchr(aux, ' ');

        if(act) //si sigue encontrando espacios a esta altura es porque se escribió algo invalido.
        {
            mostrarError();
            return 0;
        }

        int flag = 1;
        if(strcmp(sexo, "M") != 0 && strcmp(sexo, "H") != 0)
        {
            printf("\nERROR: Cuando se da de alta el tercer campo (sexo) debe ser M/H.\n");
            flag = 0;
        }

        if(strcmp(castrado, "CA") != 0 && strcmp(castrado, "SC") != 0)
        {
            printf("\nERROR: Cuando se da de alta el ultimo campo (si fue castrado o no) debe ser CA/SC.\n");
            flag = 0;
        }

        //si llega hasta acá no tuvo errores.
        return flag;
    }

//si llega hasta acá algo salió mal.
    return 0;
}

void mostrarError()
{
    printf("\nERROR. La solicitud ingresada no es válida.\n");
    printf("La solicitud debe ser de la forma:\nCOMANDO Nombre Raza Sexo(M/H) Condición (CA/SC).\n");

}

void manejador(int sig)
{
    puts("\n\nEL PROCESO SERVIDOR HA FINALIZADO\n\nSE TERMINARÁ AL PROCESO CLIENTE TAMBIÉN\n");
    kill(getpid(), SIGINT);
}