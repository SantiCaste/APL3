#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <ctype.h>
#include <iostream>
#include <signal.h>

using namespace std;

//DECLARACIONES =======================================================================
#define PARAMETRO_INVALIDO 2

char comandoEntrada[40]; //texto
char comandoSalida[40]; // ID;OTRA INFO
char respuesta[400];

//AYUDA =====================================================================================================================================
void MostrarAyuda(){
	cout << "\nEste script se emplea para realizar consultas sobre la informaciòn de manera automatizada a un Servidor del supermercado.\n";
	cout <<	"\nAclaraciones: Parametro cantidad de productos en REPO hasta INT_MAX_VALUE, Parametro ID en STOCK hasta 5 digitos.\n";
	cout << "Ejemplo de llamado:\n./Cliente";
	cout << "\nInputs interactivos:\nOPCION, opcion de lo que se quiere consultar (EN MAYUSCULA)\n.<Numero>, id de producto en STOCK / cantidad de productos en REPO.\n";
	cout << "\nOpciones de input:\nSTOCK 3\n./Cliente SIN_STOCK\n./Cliente LIST\n./Cliente REPO 5\n";				
}

//FUNCIONES ===========================================================================
int validarParametro() {		
	//if (strstr(comandoEntrada,"SIN_STOCK") != NULL) {
	if (comandoEntrada[0] == 'S' && comandoEntrada[1] == 'I' && comandoEntrada[2] == 'N' && comandoEntrada[3] == '_' && comandoEntrada[4] == 'S' && comandoEntrada[5] == 'T' && comandoEntrada[6] == 'O' && comandoEntrada[7] == 'C' && comandoEntrada[8] == 'K' && comandoEntrada[9] == '\0' ) {
		strcpy(comandoSalida,"2");																
	}
	else if (comandoEntrada[0] == 'S' && comandoEntrada[1] == 'T' && comandoEntrada[2] == 'O' && comandoEntrada[3] == 'C' && comandoEntrada[4] == 'K' && comandoEntrada[5] == ' ') {
	
		int i=6;
		while (comandoEntrada[i] != '\0') {
			if (!(comandoEntrada[i] >= '0' && comandoEntrada[i] <= '9')) { // no es numero
				return PARAMETRO_INVALIDO;
			}
			i++;
		}
		
		int id;
		char* pos=strchr(comandoEntrada,' ');
		sscanf(pos+1,"%d",&id);
		if (id < 0)
			return PARAMETRO_INVALIDO;
			
		sprintf(comandoSalida,"1;%d",id);
	}
	else if (comandoEntrada[0] == 'R' && comandoEntrada[1] == 'E' && comandoEntrada[2] == 'P' && comandoEntrada[3] == 'O' && comandoEntrada[4] == ' ') {
		
		int i=6;
		while (comandoEntrada[i] != '\0') {
			if (!(comandoEntrada[i] >= '0' && comandoEntrada[i] <= '9')) { // no es numero
				return PARAMETRO_INVALIDO;
			}
			i++;
		}
		
		int cant;
		char* pos=strchr(comandoEntrada,' ');
		sscanf(pos+1,"%d",&cant);
		if (cant < 0)
			return PARAMETRO_INVALIDO;
			
		sprintf(comandoSalida,"3;%d",cant);
	}
	else if (comandoEntrada[0] == 'L' && comandoEntrada[1] == 'I' && comandoEntrada[2] == 'S' && comandoEntrada[3] == 'T' && comandoEntrada[4] == '\0' ) {
		strcpy(comandoSalida,"4");
	}
	else 
		return PARAMETRO_INVALIDO;
	return 0;
}
//MAIN ================================================================================
int main(int argc, char* argv[]){

	FILE *p = fopen(".existeCliente","r");
	if (!p) {
		p = fopen(".existeCliente","w");
		fclose(p);
	}
	else {
		cout << "Error: Cliente ya en ejecucion\n";
		return 0;
	}
//------------------------------------------------------------------------------------

	if(argc > 1) {
		
		if ((strcmp(argv[1],"-h") == 0) || (strcmp(argv[1],"--help") == 0)) 
			MostrarAyuda();
		else
			cout << "\nError: el proceso no recibe parametros\n";
		
		int r = open("./FIFO2", O_RDONLY); //recibe de 2
		int w = open("./FIFO1", O_WRONLY); //escribe en 2
		write(w,"5",sizeof("5")); //paso QUIT para q cierre todo y cierro yo
		close(r);
		close(w);
		
		remove(".existeCliente");
		return 0;
	} 	
	
	signal(SIGINT, SIG_IGN);

	int r = open("./FIFO2", O_RDONLY); //recibe de 2
	int w = open("./FIFO1", O_WRONLY); //escribe en 2
	
	char comando[40];
		
	cout << "\nIngrese comando: ";
	fgets(comandoEntrada,40,stdin);
	char* pos = strchr(comandoEntrada,'\n');
	*pos = '\0';
	
	while(!(comandoEntrada[0] == 'Q' && comandoEntrada[1] == 'U' && comandoEntrada[2] == 'I' && comandoEntrada[3] == 'T' && comandoEntrada[4] == '\0')){ 
		
		int err = validarParametro(); //valido texto y transformo en info que voy a pasar
		if (err == PARAMETRO_INVALIDO) {
			cout << "Error: Los parametros que ingreso son invalidos";
		}
		else {
			
			write(w,comandoSalida,40); //paso info
			read(r,respuesta,400); //espero salida
			while(strcmp(respuesta,"fin") != 0){
				cout << respuesta;
				read(r,respuesta,400); //espero salida
			}
	 	}
	 		
		cout << "\n==========================================================";
		cout << "\n==========================================================";
		cout << "\n\nIngrese comando: ";
		fgets(comandoEntrada,40,stdin);
		pos = strchr(comandoEntrada,'\n');
		*pos = '\0';
	}		
	
	write(w,"5",sizeof("5")); //paso QUIT para q cierre todo y cierro yo
	close(r);
	close(w);
	
	remove(".existeCliente");
	
	return 0;
}
