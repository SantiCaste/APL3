#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <string>
#include <sys/stat.h>
#include <stdlib.h>
#include <ctype.h>
#include <vector>
#include <iostream>
#include <cstring>
#include <signal.h>

using namespace std;

//DECLARACIONES =======================================================================
#define ARG_PRODUCTOS 1

#define ERROR_ARCHIVO 1
#define ERROR_LINEA 2
#define ARCHIVO_VACIO 3

typedef struct {
	int ID;
	char descripcion[30];
	int precio;
	int costo;
	int stock;
} t_producto;

vector<t_producto> productos;

char salida [400];

//AYUDA =====================================================================================================================================
void MostrarAyuda(){
	cout << "\nEste script se emplea para responder a consultas sobre la informaciòn de manera automatizada a un CLiente del supermercado.\n";
	cout <<	"\nAclaraciones: Hay limitacion en cuanto al tamaño de los datos por cuestiones de implementaciòn. ID hasta 5 digitos, Stock hasta 9 digitos, Descripciòn hasta 30 digitos, Costo hasta 9 digitos.\n";
	cout << "\nParametros recibidos: <Nombre de archivo con informacion>\n";
	cout << "Ejemplo de llamado: ./Servidor 'Productos.txt'\n";
}

//FUNCIONES ===========================================================================
int leerLinea(char* linea, t_producto* prod){

	char* pos=strchr(linea,'\n');
	if (!pos)
		return ERROR_LINEA;
		
	pos=strrchr(linea,';'); //salteo ultimo coso
	*pos='\0';
	
	pos=strrchr(linea,';');
	sscanf(pos+1,"%d",&prod->stock);
	*pos='\0';
	
	pos=strrchr(linea,';');
	sscanf(pos+1,"%d",&prod->costo);
	*pos='\0';
	
	pos=strrchr(linea,';');
	sscanf(pos+1,"%d",&prod->precio);
	*pos='\0';
	
	pos=strrchr(linea,';');
	strncpy (prod->descripcion,pos+1,30);
	*pos='\0';
	
	sscanf(linea,"%d",&prod->ID);
	
	return 0;
}

int leerProductos(const char* nombre){
	FILE *pArch = fopen(nombre,"r");
	if (!pArch)
		return ERROR_ARCHIVO;
		
	char linea[100]; //validar info correcta
	t_producto prod;
	
	fgets(linea,100,pArch); //salteo primera
	if(feof(pArch))
		return ARCHIVO_VACIO;
		
	fgets(linea,100,pArch);
	while (!feof(pArch)){
		int err = leerLinea(linea,&prod);
		if (!err)
			productos.push_back(prod);
		else
			return ERROR_LINEA;
		fgets(linea,100,pArch);
	}
	fclose(pArch);
	return 0;
}

// FUNCIONES DE SWITCH ===========================================================================
int mostrarProducto(int id){
	
	int encontrado = 0;
	int wf = open("./FIFO2", O_WRONLY);

	for(t_producto p: productos) {
		if(p.ID == id) {
			sprintf(salida,"\nEl articulo %d es %s y tiene %d unidad/es en stock", p.ID, p.descripcion, p.stock);
			write(wf,salida,400);
			encontrado = 1;
		}
	}
	
	close(wf);
	
	if(encontrado == 1)
		return 0;
	else
		return 1;
}

//------------------------------------------------------------------------------------------------
int mostrarStockCero() {
	int encontrado = 0;
	int wf = open("./FIFO2", O_WRONLY);
	
	sprintf(salida,"\nProductos con stock 0:\n\nID   |DESCRIPCION                  |COSTO\n-----------------------------------------------");
	write(wf,salida,400);
	for(t_producto p: productos) {
		if(p.stock <= 0) {
			sprintf(salida,"\n%-5d|%-30s|%-9d",p.ID, p.descripcion, p.costo);
			write(wf,salida,400);
			encontrado = 1;
		}
	}
	
	close(wf);
	
	if(encontrado == 1)
		return 0;
	else
		return 1;
}

//------------------------------------------------------------------------------------------------
long int mostrarCostoRepo(int cant) {

	long int costo = 0;
	
	for(t_producto p: productos) {
		if(p.stock <= 0) {
			costo += cant * p.costo;
		}
	}
	
	return costo;
}

//------------------------------------------------------------------------------------------------
int listar() {
	
	int hayProd = 0;
	int wf = open("./FIFO2", O_WRONLY);
	
	sprintf(salida,"\nID |DESCRIPCION                  |PRECIO   \n----------------------------------------------------------");
	write(wf,salida,400);
		for(t_producto p: productos) {
			sprintf(salida,"\n%-3d|%-30s|%-9d",p.ID, p.descripcion, p.precio);
			write(wf,salida,400);
			hayProd=1;
		}
		
	close(wf);

	if(hayProd == 1) 
		return 0;
	else
		return 1;
}

//MAIN ================================================================================
int main(int argc, char* argv[]){

	FILE *p = fopen(".existeServidor","r");
	if (!p) {
		p = fopen(".existeServidor","w");
		fclose(p);
	}
	else {
		cout << "Error: Servidor ya en ejecucion\n";
		return 0;
	}
//------------------------------------------------------------------------------------
	if (argc < 2) {
		cout << "Error: Segundo parametro obligatorio\n";
		remove(".existeServidor");
		return 0;
	}
	
	if ((strcmp(argv[1],"-h") == 0) || (strcmp(argv[1],"--help") == 0)) {
		MostrarAyuda();
		remove(".existeServidor");
		return 0;
	}
	
	signal(SIGINT, SIG_IGN);

//------------------------------------------------------------------------------------	
	int errArch;
	errArch=leerProductos(argv[ARG_PRODUCTOS]);
	if(errArch == 1) {
		printf("Error: Hay un error en la apertura del archivo\n");
		remove(".existeServidor");
		return 0;
	}
	else if(errArch == 2) {
		printf("Error: Hay un error con las lineas del archivo\n");
		remove(".existeServidor");
		return 0;
	}
	else if(errArch == 3) {
		printf("Error: Archivo vacio\n");
		remove(".existeServidor");
		return 0;
	}
// -----------------------------------------------------------------------------------	
	pid_t pid = fork();
	if(pid < 0) {
		cout << "Error: No se puede ejecutar el srcipt.\n";
		return 0;
	}
	if(pid > 0) {
		return 0;
	}
	pid_t sid = setsid();
	if(sid < 0) {
		cout << "Error: No se puede ejecutar el srcipt.\n";
		return 0;
	}
// -----------------------------------------------------------------------------------
	
	mkfifo("./FIFO1",0666); //recibe de 1
	mkfifo("./FIFO2",0666); //escribe en 2
	
	int w = open("./FIFO2", O_WRONLY);
	int r = open("./FIFO1", O_RDONLY);
	
	char comando[40]; 
	read(r,comando,40); // ID;OTRA INFO
	
	while(comando[0] != '5') { //5 = quit
		if(comando[0] == '1') {
			int id;
			char* pos = strchr(comando,';');
			sscanf(pos+1,"%d",&id);
			int err = mostrarProducto(id);
			if (err) {
				sprintf(salida,"\nError: No se encontro el producto solicitado.");
				write(w,salida,400);
			}
			write(w,"fin",400);
		}
		else if(comando[0] == '2') {
			int err = mostrarStockCero();
			if (err) {
				sprintf(salida,"\nNo hay productos con stock cero");
				write(w,salida,400);
			}
			write(w,"fin",400);
		}
		else if(comando[0] == '3') {
			int cant;
			char* pos = strchr(comando,';');
			sscanf(pos+1,"%d",&cant);
			if (cant == 0) {
				sprintf(salida,"\nCosto de reponer 0 productos de cada stock 0: $0");
				write(w,salida,400);
			} 
			else {
				long int costo = mostrarCostoRepo(cant);
				if (costo == 0) {
					sprintf(salida,"\nNo hay productos con stock cero");
					write(w,salida,400);
				}
				else {
					sprintf(salida,"\nCosto de reponer %d productos de cada stock 0: $%ld", cant, costo);
					write(w,salida,400);
				}
			}
			write(w,"fin",400);

		}	
		else if(comando[0] == '4') {
			int err = listar();
			if (err) {
				sprintf(salida,"\nNo hay productos");
				write(w,salida,400);
			}
			write(w,"fin",400);
		}

		read(r,comando,40); // ID;OTRA INFO
	}

	// cuando recibe quit cierra todo
	
	close(r);
	close(w);
	
	unlink("./FIFO1");
	unlink("./FIFO2");
	
	remove(".existeServidor");	
	
	return 0;
}

